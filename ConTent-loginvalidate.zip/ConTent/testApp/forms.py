from django.contrib.auth.models import User
from django import forms
from .models import *


class CustomerRegisterForm(forms.ModelForm):
    first_name = forms.CharField(label='Imię',error_messages={'required': 'To pole jest wymagane!'})
    last_name = forms.CharField(label='Nazwisko',error_messages={'required': 'To pole jest wymagane!'})
    phone_number = forms.CharField(label='Telefon',error_messages={'required': 'To pole jest wymagane!'})
    password = forms.CharField(label='Hasło',widget=forms.PasswordInput,error_messages={'required': 'To pole jest wymagane!'})
    email = forms.CharField(label='E-mail',error_messages={'unique': 'Ten email istnieje w bazie!'})
    class Meta:
        model = MyUser
        fields = ['first_name', 'last_name', 'phone_number', 'email','password']
        exclude = ['email_validated', 'is_active','is_superuser']


class FieldOwnerRegisterForm(forms.ModelForm):
    first_name = forms.CharField(label='Imię',error_messages={'required': 'To pole jest wymagane!'})
    last_name = forms.CharField(label='Nazwisko',error_messages={'required': 'To pole jest wymagane!'})
    phone_number = forms.CharField(label='Telefon',error_messages={'required': 'To pole jest wymagane!'})
    password = forms.CharField(label='Hasło',widget=forms.PasswordInput,error_messages={'required': 'To pole jest wymagane!'})
    email = forms.CharField(label='E-mail',error_messages={'unique': 'Ten email istnieje w bazie!'})
    company_name = forms.CharField(label='Nazwa firmy',error_messages={'required': 'To pole jest wymagane!'})
    company_NIP = forms.CharField(label='NIP',error_messages={'required': 'To pole jest wymagane!','max_length': 'NIP maksymalnie 10 znaków!'})
    company_REGON = forms.CharField(label='Regon',error_messages={'required': 'To pole jest wymagane!','max_length': 'NIP maksymalnie 9 znaków!'})
    company_postal_code = forms.CharField(label='Kod pocztowy',error_messages={'required': 'To pole jest wymagane!','max_length': 'Kod pocztowy maksymalnie 5 znaków!'})
    company_locality = forms.CharField(label='Miasto',error_messages={'required': 'To pole jest wymagane!'})
    company_address = forms.CharField(label='Adres',error_messages={'required': 'To pole jest wymagane!'})
    class Meta:
        model = FieldOwner
        fields = ['first_name', 'last_name', 'phone_number', 'email','password','company_name','company_NIP','company_REGON','company_postal_code','company_locality','company_address']
        exclude = ['account_validated']

    def clean_email(self):
        email = self.cleaned_data['email']
        check = MyUser.objects.filter(email=email)
        if check.count() > 0:
            raise forms.ValidationError("Ten email istnieje w bazie!")
        return email